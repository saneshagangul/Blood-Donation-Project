package Models;
public class NurseDetails 
{
    String Nname;
    String Nid;
    String contact;
    String qualification;
    String address;
    String gender;
    int age;
    
    public NurseDetails(String Nname,String Nid,String contact,String qualification,String address,String gender,int age)

    {
    
        this.Nid=Nid;
        this.Nname=Nname;
        this.address=address;
        this.age=age;
        this.gender=gender;
        this.qualification=qualification;
        this.contact=contact;

    }

}
