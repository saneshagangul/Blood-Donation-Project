
package Models;

public class DonorDetails 
{
    String name;
    String id;
    int age;
    String Address;
    String contact;
    String gender;
    double weight;
    double height;
    double BP;
    String bloodgroup;
    int DAmout;
    
    String DId;
    String NId;
    
    public DonorDetails(String name,int age,String contact,
           String gender,double weight,double height,String bloodgroup,
           int RAmout,String Address,double BP,String DId,String NId)
    {
        this.name=name;
        this.DAmout=RAmout;
        this.Address=Address;
        this.BP=BP;
        this.age=age;
        this.contact=contact;
        this.gender=gender;
        this.weight=weight;
        this.height=height;
        this.bloodgroup=bloodgroup;        
        this.DId=DId;
        this.NId=NId;
    }
    public double calBMI()
    {
        class BMI
        {
            double weightM;
            double heightM;
            double bmiMetric()
            {
                double result=weightM/(heightM*heightM);
                return result;
            }            
        }
        BMI b=new BMI();
        b.heightM=this.height;
        b.weightM=this.weight;
        return b.bmiMetric();
    }
    
}
