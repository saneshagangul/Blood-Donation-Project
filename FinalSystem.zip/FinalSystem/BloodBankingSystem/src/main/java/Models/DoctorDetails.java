package Models;

public class DoctorDetails 
{
    String Dname;
    String Did;
    String contact;
    String qualification;
    String address;
    String gender;
    int age;
    String email;
    
    public DoctorDetails(String Dname,String Did,String contact,String qualification,String address,String gender,int age,String email)

    {
    
        this.Did=Did;
        this.Dname=Dname;
        this.address=address;
        this.age=age;
        this.gender=gender;
        this.qualification=qualification;
        this.contact=contact;
        this.email=email;

    }

    public DoctorDetails() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}


