package Models;

import FrontEnd.Login;



public class BloodBanking 
{
    public static void main(String [] args)
    {
        Login UI=new Login();
        UI.show();
        
    }

    public void show() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void show(String oi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
