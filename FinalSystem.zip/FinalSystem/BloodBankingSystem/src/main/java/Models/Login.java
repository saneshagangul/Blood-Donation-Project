
package Models;

public class Login 
{
    public String userId;
    public String password;
    
    public Login(String userId, String password)
    {
        this.userId=userId;
        this.password=password;
        
    }
    //need's to check whether the password and user name is correct
}
