
package Models;

public class Patient 
{
    String Pname;
    String Pid;
    String contact;
    String Reason;
    String address;
    int RAmount;
    String gender;
    int age;
    String bloodgroup;
    
    public Patient( String Pname,String Pid,String contact,String Reason,String address,int RAmount,String gender,int age,String bloodgroup)
    {
        this.Pname=Pname;
        this.Pid=Pid;
        this.RAmount=RAmount;
        this.address=address;
        this.bloodgroup=bloodgroup;
        this.Reason=Reason;
        this.age=age;
        this.gender=gender;
        this.contact=contact;
    }
}
