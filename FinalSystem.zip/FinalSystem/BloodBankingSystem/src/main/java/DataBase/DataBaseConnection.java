package DataBase;

import java.sql.*;
import javax.swing.*;

public class DataBaseConnection 
{
    private static Connection con=null;
    public static Connection DataBaseConnection()
    {
        try
        {
            String url="jdbc.sql:DataBase.sql";
            con=DriverManager.getConnection(url);
            return con;
            
        }catch(SQLException ex)
                {
                   return null; 
                }
        
    }
    
}
